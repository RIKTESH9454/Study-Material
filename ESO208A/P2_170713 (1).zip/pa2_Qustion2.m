clear;
fprintf("Enter the method you want to use\n");
fprintf("1. Power method\n2. QR method\n");
meth = input('');
%------------------power method--------------------
if meth==1
  fprintf("Give your input in a file named 'input2.txt'\n");
  fprintf("FORMAT: \n Size of matrix \n matrix  \n Maximum approximate relative error \n ");
  file=fopen("input2.txt");
  line=fgetl(file);
  n=sscanf(line, '%f' );
  A=zeros(n,n);
  temp=zeros(1,n);
  for i=1:1:n
    line = fgetl(file);
    A(i,1:1:n) = sscanf(line, '%f ');
  end; 
  line = fgetl(file);
  maxerr = sscanf(line, '%f ');
  error=100;
  maxeval=1;
  y=zeros(n,1);
  z=zeros(n,1);
  y(1,1)=1;
  while error>maxerr
      z=A*y;
      lambda=0;
      for i=1:1:n
          lambda=lambda+z(i,1)^2;
      end
      lambda=sqrt(lambda);
      y=z/lambda;
      error=(abs(maxeval-lambda)/lambda)*100;
      maxeval=lambda;
  end
  disp(maxeval)
  filename = 'output-power.txt';
  outf = fopen (filename, 'w');
  fprintf(outf,"Largest eigen value by power method: \r\n");
  fprintf(outf,'%6.4f\r\n',maxeval);
  fclose(outf);
end
%-------------------QR decomposition------------------------
if meth==2
  fprintf("Give your input in a file named 'input2.txt'\n");
  fprintf("FORMAT: \n Size of matrix \n matrix  \n Maximum approximate relative error \n ");
  file=fopen("input2.txt");
  line=fgetl(file);
  n=sscanf(line, '%f' );
  A=zeros(n,n);
  temp=zeros(1,n);
  for i=1:1:n
    line = fgetl(file);
    A(i,1:1:n) = sscanf(line, '%f ');
  end; 
  line = fgetl(file);
  maxerr = sscanf(line, '%f ');
  error=100;
  iter=1;
  while error>maxerr
      %iter=iter+1;
      Q = zeros(n,n);
    for i=1:1:n
      if i==1
        ymod=0;
        for j=1:n
          ymod = ymod + A(j,1)^2;
        end;
        ymod = sqrt(ymod);
        Q(:,1) = A(:,1)./ymod;
      else
        Q(:,i) = A(:,i);
        for  k=1:i-1
          Q(:,i) = Q(:,i) - ((A(:,i)')*Q(:,k)).*Q(:,k);
        end;
        ymod=0;
        for j=1:1:n
          ymod = ymod + Q(j,i)^2;
        end;
        ymod = sqrt(ymod);
        Q(:,i) = Q(:,i)./ymod;
      end;
    end;
      
        R=zeros(n,n);
        for i=1:1:n
           for j=1:1:n
               if j>=i
                   R(i,j)=(Q(:,i)')*A(:,j);
                 
               end
           end
        end
       
      B=R*Q;
      curerror=0;
      for i=1:1:n
          curerror = max (curerror,(abs((A(i,i)-B(i,i))/B(i,i))*100));
      end;
      A = B;
      error=curerror;
  end
  for i=1:1:n
      evals(1,i)=A(i,i);
  end
  filename = 'output-QR.txt';
  outf = fopen (filename, 'w');
  fprintf(outf,"Eigen values by QR method: \r\n");
  fprintf(outf,'%6.6f\r\n',evals);
  fclose(outf);
  
end


  
      
                  
      
              
              
              
    

          
      
      
  