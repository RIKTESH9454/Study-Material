fprintf('Enter the grid size \n');
h=input(' ');
n = (2/h)+1;
a = @(x) 1-((-(x+3)/(x+1))*h)/2;
b = @(x) (h^2)*((x+3)/(x+1)^2)-2;
c = @(x) 1+((-(x+3)/(x+1))*h)/2;
f  = @(x) (2*(x+1)+3*((x+3)/(x+1)^2))*(h^2);
fprintf('Choose the implementation method: \n1. 2nd Order backward difference \n2. 2nd order central difference with ghost node \n');
meth=input(' '); 
if meth==1
    alpha = zeros(1,n-1);
        l = [];
        for i = 1:n-1
            if(i==1)
                l(i) = 0;    
            elseif(i==n-1)
                l(i) = 2;
            else
                l(i) = a(h*(i));
            end    
        end
        u = [];
        for i = 1:n-1
            if(i==n-1)
                u(i) = 0;
            else
                u(i) = c(h*(i));
            end    
        end
        for i = 1:n-1
            d(i) = b(h*(i));    
        end
        B = [];
        for i = 1:n-1
            if(i==1)
                B(i)=f(h*(i))-(a(h*(i)))*5;
            else
                B(i)=f(h*(i));
            end    
        end    
        alpha(1) = d(1);
        beta = zeros(1,n-1);
        beta(1) = B(1);
        for i=2:n-1
            alpha(i) = d(i)-(l(i)/alpha(i-1))*u(i-1);
            beta(i) = B(i)-(l(i)/alpha(i-1))*beta(i-1);
        end
        x = zeros(1,n-1);
        x(n-1)=beta(n-1)/alpha(n-1);
        for i = 1:n-2
            x(n-1-i) = (beta(n-1-i)-u(n-1-i)*x(n-i))/alpha(n-1-i);
        end
end

if meth==2
        alpha = zeros(1,n-1);
        l = [];
        for i = 1:n-1
            if(i==1)
                l(i) = 0;    
            elseif(i==n-1)
                l(i) = 4*a(h*(i))+b(h*(i));
            else
                l(i) = a(h*(i));
            end    
        end
        u = [];
        for i = 1:n-1
            if(i==n-1)
                u(i) = 0;
            else
                u(i) = c(h*(i));
            end    
        end
        for i = 1:n-1
            if(i==n-1)
                d(i)=c(h*(i))-3*a(h*(i));
            else
                d(i) = b(h*(i));  
            end
        end
        B = [];
        for i = 1:n-1
            if(i==1)
                B(i)=f(h*(i))-(a(h*(i)))*5;
            else
                B(i)=f(h*(i));
            end    
        end    
        alpha(1) = d(1);
        beta = zeros(1,n-1);
        beta(1) = B(1);
        for i=2:n-1
            alpha(i) = d(i)-(l(i)/alpha(i-1))*u(i-1);
            beta(i) = B(i)-(l(i)/alpha(i-1))*beta(i-1);
        end
        x = zeros(1,n-1);
        x(n-1)=beta(n-1)/alpha(n-1);
        for i = 1:n-2
            x(n-1-i) = (beta(n-1-i)-u(n-1-i)*x(n-i))/alpha(n-1-i);
        end
end
for i=1:20
    t(i)=h*i;
end
plot(t,x);
    